/**
 * Copyright (c) 2022 ZEP Co., LTD
 */
App.showCenterLabel("Hello World");
let zepLogo = App.loadSpritesheet("zep_logo.png");
Map.putObject(0, 0, zepLogo, {
  overlap: true
});
let _answer = "ZEP";
App.onSay.Add(function (player, text) {
  if (_answer == text) {
    App.showCenterLabel(player.name + ' Correct!\nThe answer is ' + _answer);
  }
});
App.onDestroy.Add(function () {
  Map.clearAllObjects();
});