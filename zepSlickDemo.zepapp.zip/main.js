/**
 * Copyright (c) 2022 ZEP Co., LTD
 */
let zepLogo = App.loadSpritesheet("zep_logo.png");
Map.putObject(0, 0, zepLogo, {
  overlap: true
}); // ScriptApp.httpPost(
//   "https://postman-echo.com/post",
//   null,
//   {
//     name: "zepscript",
//   },
//   (res) => {
//     // Change the response to a json object
//     // let response = JSON.parse(res);
//     // ScriptApp.sayToAll(`header sent: ${response.headers["test-header"]}`, 0xffffff);
//     // ScriptApp.sayToAll(`data sent: ${response.form.name}`, 0xffffff);
//     ScriptApp.showCenterLabel("TRALAL");
//   }
// );

App.onSay.Add(function (player, text) {
  App.httpPost("http://168.63.243.40:30035/inference", null, {
    text: text
  }, res => {
    var response = JSON.parse(res);
    var type = response[0]["text_label"];

    if (type == "banned") {
      App.showCenterLabel("Banned word detected!");
    }
  });
});
App.onDestroy.Add(function () {
  Map.clearAllObjects();
});